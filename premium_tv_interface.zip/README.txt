PREMIUM TV HOME — PROTOTYPE

This is a visual, interactive browser prototype for the proposed minimalist TV home screen. It includes YouTube TV and Apple TV. It supports mouse/touch and left/right arrow + Enter keyboard navigation.

IMPORTANT: This is not installed on the Samsung TV and does not replace the Samsung home screen or launch streaming apps. Samsung's Tizen TV normally does not permit a third-party app to replace the system launcher. To make a true custom launcher, you will likely need a compatible external device; then we can adapt the interface for that platform.

Preview: open index.html in a modern web browser. The scenic background and poster imagery load from Unsplash, so those images need internet access.
